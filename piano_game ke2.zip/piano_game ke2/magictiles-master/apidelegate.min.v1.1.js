var APIDelegate = {
    VERSION: "1.1",
    startupObj: {
        callback: null,
        context: null
    },
    enterGameObj: {
        callback: null,
        context: null
    },
    get LogoUrl() {
        return com4j.config.ForJoyH5_SmallLogo
    },
    get CreditsEnabled() {
        return com4j.config.ForJoyH5_ShowCreditsButton
    },
    get MoregamesEnabled() {
        return com4j.config.ForJoyH5_ShowMoreGamesButton
    },
    get FullscreenEnabled() {
        return com4j.config.ForJoyH5_Fullscreen
    },
    startup: function(b, a) {
      
        this.startupObj.callback = b;
        this.startupObj.context = a;
       
    },
    _onApiInited: function() {
        MGDelegate.addEventListener(MGEvent.ENTER_GAME, this._enterGame, APIDelegate);
        if (this.startupObj.callback) {
            this.startupObj.callback.apply(this.startupObj.context)
        }
    },
    enterGame: function(b, a) {
        this.enterGameObj.callback = b;
        this.enterGameObj.context = a
    },
    _enterGame: function() {
        if (this.enterGameObj.callback) {
            this.enterGameObj.callback.apply(this.enterGameObj.context)
        }
    },
    loadStart: function() {
        this._dispatch(MGEvent.LOAD_START)
    },
    loadProgress: function(a) {
        this._dispatch(MGEvent.LOAD_PROGRESS, {
            percent: a
        })
    },
    loadComplete: function() {
        this._dispatch(MGEvent.LOAD_COMPLETE)
    },
    clickLogo: function() {
        this._dispatch(MGEvent.CLICK_MINILOGO)
    },
    clickMore: function() {
        this._dispatch(MGEvent.CLICK_MORE)
    },
    clickCredits: function() {
        this._dispatch(MGEvent.CLICK_CREDITS)
    },
    clickFullscreen: function() {
        this._dispatch(MGEvent.FULLSCREEN)
    },
    changeScene: function(c, a) {
        if (c) {
            var b = {
                callback: c,
                thisObj: a
            }
        }
        this._dispatch(MGEvent.CHANGE_SCENE, b)
    },
    showWin: function() {
        this._dispatch(MGEvent.SHOW_WIN)
    },
    showLose: function() {
        this._dispatch(MGEvent.SHOW_LOSE)
    },
    levelWin: function(a) {
        this._dispatch(MGEvent.LEVEL_WIN, {
            level: a
        })
    },
    levelLose: function(a) {
        this._dispatch(MGEvent.LEVEL_FAIL, {
            level: a
        })
    },
    resizeHandler: function(c, a, b) {
        
    },
    _dispatch: function(b, c) {
        var a = new MGEvent(b);
        a.data = c;
        MGDelegate.dispatcherEvent(a)
    }
};
